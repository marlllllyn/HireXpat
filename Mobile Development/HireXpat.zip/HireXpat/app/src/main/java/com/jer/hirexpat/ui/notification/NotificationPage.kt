package com.jer.hirexpat.ui.notification

import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun NotificationPage(
    modifier: Modifier = Modifier
) {
    Box {
        Text(text = "Notification Page")
    }
}