package com.jer.hirexpat.model

data class JobList(
    val id: Long,
    val jobTitle: String,
    val company: String,
    val photoJob: String,
)
