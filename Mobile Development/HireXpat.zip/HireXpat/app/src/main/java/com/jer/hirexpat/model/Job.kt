package com.jer.hirexpat.model

data class Job(
    val id: Long,
    val jobTitle: String,
    val company: String,
    val descJob: String,
    val photoJob: String,
)
